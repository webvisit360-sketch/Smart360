# Urejevalnik naslovnice — specifikacija

Delujoč vzorec: `predogled-poteg.html` → gumb z drsniki zgoraj desno na naslovnici.
Označba urejevalnika je v `zasloni-poteg.html` na dnu.

## Polja

| Polje v bazi (`Tenant`) | Nadzor v administraciji | Meje | Privzeto |
|---|---|---|---|
| `coverTitle` | besedilno polje | prosto | ime nastanitve |
| `coverSubtitle` | besedilno polje | prosto | podnaslov nastanitve |
| `coverTitleSize` | drsnik, px | 24–84 | **56** |
| `coverTitleOpacity` | drsnik, % | 20–100 | **66** |
| `coverTextColor` | izbirnik + 6 prednastavljenih | hex | **#FFFFFF** |
| `coverSubSize` | drsnik, px | 12–40 | **22** |
| `coverSubOpacity` | drsnik, % | 20–100 | **50** |
| `coverMetaSize` | drsnik, px | 12–32 | **19.5** |
| `coverMetaOpacity` | drsnik, % | 20–100 | **60** |
| `coverVeil` | drsnik, % | 0–60 | **26** |
| `coverAlign` | dva gumba: Levo / Sredina | left \| center | **left** |
| `coverShowRating` | dva gumba: Prikaži / Skrij | bool | **true** |
| `navColorCover` | izbirnik + 6 prednastavljenih | hex | **#FFFFFF** |
| `navColor` | izbirnik + 6 prednastavljenih | hex | **#14201F** |
| `navColorOn` | izbirnik + 6 prednastavljenih | hex | **#3B78DC** |

Zadnje tri so barve **spodnjih ikon**: na naslovnici, na podstraneh in barva izbrane ikone.
Poleg šestih prednastavljenih barv ima vsako polje tudi `<input type="color">` za **poljubno barvo**.

Prednastavljene barve: `#FFFFFF`, `#F6F1E9`, `#FFE9B8`, `#3B78DC`, `#14201F`, `#C4552E`.

## Kako se vrednosti prenesejo na javno stran

Ne piši novih razredov. Vrednosti nastavi kot **CSS spremenljivke** na korenu dokumenta (ali na `.cover`), CSS jih že bere:

```js
const r = document.documentElement.style;
r.setProperty("--tt-txt",  t.coverTextColor);
r.setProperty("--tt-size", t.coverTitleSize + "px");
r.setProperty("--tt-op",   t.coverTitleOpacity / 100);
r.setProperty("--st-size", t.coverSubSize + "px");
r.setProperty("--st-op",   t.coverSubOpacity / 100);
r.setProperty("--mt-size", t.coverMetaSize + "px");
r.setProperty("--mt-op",   t.coverMetaOpacity / 100);
r.setProperty("--veil",    t.coverVeil / 100);
r.setProperty("--cover-align", t.coverAlign);
r.setProperty("--cover-just",  t.coverAlign === "center" ? "center" : "flex-start");
r.setProperty("--nv",       t.navColor);
r.setProperty("--nv-on",    t.navColorOn);
r.setProperty("--nv-cover", t.navColorCover);
```

Pri strežniškem izrisu (SSR) enako, samo kot `style` atribut na `.cover`, da ni utripanja ob nalaganju.

## Obnašanje urejevalnika

- **Živ predogled:** ob premikanju drsnika se naslovnica spreminja sproti, brez shranjevanja
- Ob vsakem drsniku je izpisana trenutna vrednost (npr. `56px`, `66 %`)
- Gumba **Ponastavi** (vrne privzete vrednosti iz tabele) in **Shrani**
- Vrednosti se hranijo **pri posamezni nastanitvi**, ne globalno
- Če je `coverTitle` prazen, se na javni strani izpiše `name`; enako `coverSubtitle` → `subtitle`

## Privzete vrednosti se razlikujejo po temi

Iste spremenljivke, drugačna izhodišča — ker v sredozemski temi naslov leži na beli kartici, v temi poteg pa na fotografiji. Obe temi ju **bereta**, zato urejevalnik deluje enako v obeh.

| Spremenljivka | Sredozemska | Poteg |
|---|---|---|
| `--tt-size` | 24px | 56px |
| `--tt-op` | 1 | .66 |
| `--tt-txt` | `#14201F` | `#FFFFFF` |
| `--st-size` / `--st-op` | 11px / 1 (vrstica pod imenom v glavi) | 22px / .5 (podnaslov na fotografiji) |
| `--mt-size` / `--mt-op` | 13.5px / 1 | 19.5px / .6 |
| `--veil` | 0 (zatemnitev hero fotografije) | .26 (zatemnitev cele naslovnice) |

Ob preklopu teme prazna polja samodejno prevzamejo stolpec nove teme; izpolnjena ostanejo taka, kot jih je nastavil upravitelj. Nobenega prepisovanja v bazi ni — glej razdelek o praznih vrednostih zgoraj.

## Privzetih vrednosti se NE zapisuje v bazo

Vsa polja iz zgornje tabele so v bazi **nullable in ob ustvarjanju nastanitve prazna**.
Prazno pomeni »uporabi privzeto vrednost teme«. Vrednost se zapiše šele takrat, ko
upravitelj premakne drsnik ali izbere barvo.

Ob izrisu se spremenljivka CSS nastavi **samo za polja, ki niso prazna**; za prazna velja
blok `html[data-theme=…]`.

Zakaj tako:

- **Preklop teme ne potrebuje nobenega ponastavljanja.** Prazna polja samodejno prevzamejo
  privzetke nove teme, izpolnjena ostanejo. Brez tega se ob preklopu iz teme poteg v
  sredozemsko preneseta bela barva in velikost 56 px — in naslov na beli kartici izgine.
- **»Ročno spremenjeno« je natanko »ni prazno«.** Ni ugibanja, katero vrednost je nastavil
  človek in katero sistem.
- **Gumb »Ponastavi« polja izprazni**, ne zapiše privzetkov.
- Če se privzetki teme kdaj spremenijo, jih podedujejo vse nastanitve, ki jih niso povozile.

Pri obstoječih nastanitvah: kjer je shranjena vrednost enaka privzetku svoje teme, se ob
migraciji nastavi na `NULL`.

## OBVEZNO: vsak `var()` mora imeti rezervno vrednost

Ker so polja naslovnice v bazi lahko prazna, se lahko zgodi, da spremenljivka **sploh ni
nastavljena**. CSS se v tem primeru ne obnaša mehko:

- `color:var(--tt-txt)` postane neveljaven → barva se **podeduje** od starša (temna na
  fotografiji)
- `font-size:var(--tt-size)` postane neveljaven → velikost se podeduje
- `background:rgba(10,16,20,var(--veil))` postane neveljaven → **zatemnitve ni**
- `width:calc(var(--mt-size) * 1.08)` postane neveljaven → `width:auto` → ikona zvezdice
  se **razlije čez pol zaslona**

Zadnje je videti kot huda napaka, v resnici pa je le manjkajoča spremenljivka.

Zato ima v priloženih temah **vsak** `var()` zapisano rezervno vrednost, enako privzetku
svoje teme, ikone pa še dodatno `max-width` / `max-height`:

```css
/* tema poteg */
.cover__txt h1{font-size:var(--tt-size,56px);color:var(--tt-txt,#FFFFFF);opacity:var(--tt-op,.66)}
.cover__meta .ic{width:calc(var(--mt-size,19.5px) * 1.08);height:calc(var(--mt-size,19.5px) * 1.08);
                 max-width:34px;max-height:34px}
.cover__veil{background:rgba(10,16,20,var(--veil,.26))}

/* sredozemska tema */
.tcard .title{font-size:var(--tt-size,24px);color:var(--tt-txt,#14201F);opacity:var(--tt-op,1)}
.tcard .meta .ic{width:calc(var(--mt-size,13.5px) * 1.04);height:calc(var(--mt-size,13.5px) * 1.04);
                 max-width:22px;max-height:22px}
.hero::after{background:rgba(10,16,20,var(--veil,0))}
```

Preizkus: odstrani vse spremenljivke naslovnice in naloži stran. Videti mora biti **natanko
tako kot prej** — to je edini zanesljiv dokaz, da so rezervne vrednosti povsod.

## POZOR: privzete vrednosti ne smejo biti globalne

V referenčnih datotekah je za vsako temo svoj blok `:root{…}` in naloži se **samo ena**
datoteka CSS. Če aplikacija obe temi zloži v isti sveženj, zadnji blok `:root` prepiše
prejšnjega in vrednosti druge teme veljajo povsod — v sredozemski temi to pomeni **bel
naslov na beli kartici**, torej neviden naslov.

Če se obe temi naložita skupaj, morata biti bloka omejena na temo:

```css
html[data-theme="mediterran"]{
  --tt-txt:#14201F; --tt-size:24px;  --tt-op:1;
  --st-size:11px;   --st-op:1;
  --mt-size:13.5px; --mt-op:1;
  --veil:0; --cover-align:left; --cover-just:flex-start;
}
html[data-theme="swipe"]{
  --tt-txt:#FFFFFF; --tt-size:56px; --tt-op:.66;
  --st-size:22px;   --st-op:.5;
  --mt-size:19.5px; --mt-op:.6;
  --veil:.26; --cover-align:left; --cover-just:flex-start;
}
```

Vrednosti iz administracije se še vedno pišejo na `document.documentElement.style`, ki ima
višjo veljavo od obeh blokov, zato urejevalnik deluje enako.

## Pomembno

Zatemnitev fotografije (`--veil`) je **enakomerna čez celo fotografijo**, brez preliva. Prejšnja različica je pokrivala samo spodnji del in se je čez sliko vlekla vidna vodoravna črta — tega ne ponavljaj.
