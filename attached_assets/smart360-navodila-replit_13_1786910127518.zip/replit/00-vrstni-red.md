# Smart360 · vrstni red nalog za Replit

Vsaka datoteka je samostojno navodilo — prilepi vsebino bloka v Replit, priloge pa naloži
kot datoteke. Vrstni red ni naključen: kasnejše naloge se opirajo na prejšnje.

| # | Datoteka | Kaj naredi | Kaj priložiš |
|---|---|---|---|
| 1 | `logotip-v-app.md` | vstavi logotip Smart360 v glavo, na naslovnico in med ikone | `smart360-logo.zip` |
| 2 | `spodnja-vrstica-poteg.md` | spodnja vrstica s petimi ikonami + barve ikon v administraciji | `smart360-ui-paket.zip` |
| 3 | `enotne-podstrani.md` | enak videz podstrani v **obeh** temah — nikjer seznamov, povsod fotografije | — |
| ✓ | `urejanje-vsebine.md` | administracija vsebine — **narejeno** | — |
| 5 | `gumbi-in-google-maps.md` | ploski gumbi + »Google Maps« namesto »Navigacija« | — |
| 6 | `majhna-besedila.md` | majhna besedila +40 % in nastavljiva (velikost, pisava, barva) | — |
| 7 | `qr-in-deljenje.md` | gumb za deljenje, QR koda in nalepka A6 za tisk | — |
| 8 | `podrobnosti-brez-pasice.md` | podrobnosti brez zgornje pasice, naslov na vrhu vsebine (+60 %) | — |
| 9 | `listi-krizec.md` | križec v listih + popravek plasti (list je bil pod ikonami) | — |
| 10 | `naslovi-strank.md` | naslov `smart360.info/imestranke` — nova stranka dosegljiva brez dela z DNS | — |
| 11 | `logotip-melipu.md` | obrezan logotip stranke brez ozadja + pravilo za nalaganje logotipov | `melipu-logo.zip` |
| 12 | `logotip-stranke-naslovnica.md` | logotip stranke na prvi strani namesto znamke Smart360, premikanje in velikost v adminu | — |
| 13 | `nalepka-logotip-stranke.md` | nalepka in QR brez znamke Smart360 — logotip stranke | — |
| 14 | `admin-urejevalnik-besedila.md` | konec surovega HTML — urejevalnik z orodno vrstico | — |
| 15 | `admin-slicice-in-video.md` | povsod sličice namesto imen datotek + nalaganje videa | — |
| 16 | `galerija-povecava-video.md` | galerija čez cel zaslon: ščipanje, dvojni dotik, vrtenje, video | — |
| 17 | `prevodi-stiri-jeziki.md` | SL/EN/DE/IT, množinske oblike, uvoz angleškega prevoda | `prevodi-melipu.zip` |
| 18 | `namizni-zaslon.md` | na širokem zaslonu okno telefona na sredini | — |
| 19 | `iskanje-in-jezik.md` | lupa se razpre v belo iskalno vrstico + ozek bel izbirnik jezika | — |
| 20 | `wifi-in-barva-ozadja.md` | WiFi v adminu + QR za povezavo, barva ozadja za vso aplikacijo | — |
| 21 | `apartmaji-naslov-in-zamrznjena-povecava.md` | naslov nad fotografijo pri apartmajih; povečava slik zamrznjena | — |
| ✓ | `fotografije.md` | vnos 64 fotografij — **narejeno** | `fotografije.zip` |
| ✓ | `popravek-predogled.md` | predogled v novem zavihku — **narejeno** | — |

## Kako preveri, da je prav

Referenca je `smart360-poteg.html` (tema poteg) oziroma `smart360-melipu-sredozemsko.html`
(sredozemska tema). Odpri referenco in Replitovo stran eno ob drugi pri širini 390 px.
Če se karkoli razlikuje — razmik, velikost pisave, barva, oblika gumba, radij, položaj
ikone — je narobe Replitova stran, ne referenca.

V `smart360-ui-paket.zip` sta `tema-poteg.css` in `zasloni-poteg.html`: to je **končan
dizajn v obliki kode**, ne opis. Agent naj razrede in vrednosti prepiše, ne izumlja svojih.

## Tri pravila, ki se najpogosteje prekršijo

1. **Nobene knjižnice komponent** (shadcn, MUI, Chakra, Bootstrap, DaisyUI) in nobenih
   ikonskih knjižnic. Ikone samo iz priloženega sprite-a.
2. **Brez prelivov, zameglitev in prosojnosti.** Čiste polne barve, ostri rezi.
3. **Fotografija je vedno nad besedilom**, prva fotografija postavke je hkrati njena ploščica.

## Kar ostaja odprto pri Replitu

- angleški prevod vsebine (šele po `urejanje-vsebine.md`, ker se opira na tabelo prevodov)

- preizkus prijave s ključem (passkey) na resnični napravi
- kontrolni seznam za produkcijsko domeno
- preklop `RP_ID` / `RP_ORIGIN` na `admin.smart360.info` in nova prijava ključa
- gumb »← Administracija« v predogledu prekriva naslov zaslona — premakni ga v spodnji
  levi kot nad vrstico z ikonami, ali pa v načinu predogleda dodaj zgornji odmik
