# Prevodi Meli Pu

| Datoteka | Kaj je notri |
|---|---|
| `sl.json` | izvirnik — 272 vsebinskih polj, ključ je pot do polja |
| `en.json` | angleški prevod istih 272 polj + besedila vmesnika + množinske oblike |

Ključ je pot do polja v podatkih (`DATA.stay.items[2].body[3]`), ne zaporedna številka —
tako prevod ostane pri svojem besedilu, tudi če se vrstni red postavk spremeni.

**Kaj ni prevedeno in ne sme biti:** iskalni nizi za Google Maps (`q`), imena datotek,
telefonske številke, oznake zahtevnosti, razdalje in časi. Lastna imena lokalov ostanejo
v izvirniku — gost mora ime prepoznati na tabli. Prevede se samo opisni del:
»Plaža Svetilnik« → »Svetilnik Beach«, »Splošna bolnišnica Izola« → »Izola General Hospital«.

Nemščina in italijanščina gresta po istem kalupu — datoteki bosta `de.json` in `it.json`
z istimi ključi.
