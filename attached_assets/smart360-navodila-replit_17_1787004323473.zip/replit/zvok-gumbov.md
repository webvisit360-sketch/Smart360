# Zvok gumbov se je izgubil

Mehanski klik ob dotiku je bil del zasnove od začetka. V temi poteg je utihnil — ne zato,
ker bi ga kdo odstranil, ampak ker se sproža po **seznamu razredov**, ta pa je bil pisan za
prvotno temo. Nove ploščice in ikone se v seznamu ne pojavijo, zato tiho ne klikne nič.

Referenca: `smart360-poteg.html` — globus → zadnja vrstica v spustnem seznamu.

---

## Navodilo za Replit (prilepi v celoti)

```
The mechanical click on tap is gone in the swipe theme. It was not removed — the delegated
listener matches a list of class names written for the older theme, and the newer tiles and
icons are not in it. Silence by omission.

=====================================================================
1. THE LIST MUST COVER BOTH THEMES
=====================================================================

  const CLICKY = ".row,.tile,.thumb,.svc,.chip,.cat,.act,.btn,.tab,.iconbtn,.srow,.search,"
               + ".mapbtn,.hero__heart,.gc,.nv,.cover__btn,.langpop__i,.findbar__x,"
               + ".findres__r,.hcard,.big__c,.qk button,.sheet__x,.mv__b,.seg button,"
               + ".swatches button,.card__heart";
  document.addEventListener("pointerdown", e => {
    if (e.target.closest(CLICKY)) click();
  }, {passive:true});

  Better still: stop maintaining a list. Anything the guest can press should be a <button>
  or carry a data-click attribute, and the listener should match that. A list of class names
  goes stale the moment someone adds a component, and it fails silently — which is exactly
  what happened here. Say which of the two you implemented.

=====================================================================
2. THE SOUND — DO NOT REPLACE IT WITH A FILE
=====================================================================

It is synthesised with the Web Audio API, no audio file, roughly an IBM Model M: a short
filtered noise burst plus a falling square-wave chirp, about 45 ms total.

  - filtered noise: bandpass 2600 Hz, Q 1.1, gain .17 decaying to .001 over 45 ms
  - chirp: square wave 1750 Hz -> 760 Hz over 30 ms, gain .055 decaying over 35 ms
  - plus navigator.vibrate(6) where supported

  The AudioContext starts suspended on iOS: create it on the FIRST user gesture and call
  resume() there. If it is created at page load it stays suspended and the app is silent
  with no error anywhere — the second way this feature dies quietly.

=====================================================================
3. THE SWITCH MUST BE REACHABLE
=====================================================================

The on/off switch used to live in the language sheet. That sheet was replaced by the narrow
language dropdown, and the switch went with it. Put it back as the last row of the dropdown,
separated by a line, icon only (speaker / muted speaker) so the panel stays 84 px wide:

  .langpop__snd{border-top:2px solid var(--line);display:grid;place-items:center;
    color:var(--ink-2)}
  .langpop__snd .ic{width:19px;height:19px}

  Toggling it saves to localStorage, plays one click when switching ON (so the guest hears
  what they chose) and re-renders the dropdown so the icon matches the state.

  Default: sound ON. A guest who dislikes it turns it off in two taps; a guest who never
  discovers it never learns the app has a personality.

=====================================================================
4. VERIFY
=====================================================================

  a) Tap a category tile, a bottom icon, a chip, a cover button, a search result and a sheet
     row: every one clicks.
  b) On a real iPhone, the FIRST tap after loading the page already makes a sound.
  c) Turn it off in the dropdown: nothing clicks, the icon shows muted, and it stays off
     after a reload.
  d) Turn it on: one click is heard immediately.
  e) With the phone on silent, nothing plays and nothing throws.
```
