# Namizni zaslon: okno telefona na sredini

Gost skenira QR kodo s telefonom, zato mobilni prikaz ostane, kar je. Na računalniku pa
aplikacija ne sme izgledati kot raztegnjena spletna stran — postavi se v stolpec 430 px na
sredini, na mirni podlagi.

Referenca: vsi trije `smart360-*.html`, odpri jih v oknu, širšem od 760 px.

---

## Navodilo za Replit (prilepi v celoti)

```
On a wide screen the guest app must present as a phone-sized column centred on a calm
background, not as a stretched web page. Nothing about the mobile rendering changes.

=====================================================================
1. ONE WRAPPER AROUND EVERYTHING
=====================================================================

All guest-app layers go inside ONE element:

  <div class="frame" id="frame">
    <div class="app">…</div>
    <nav class="tabdock">…</nav>
    <div class="detail">…</div>
    <div class="mask"></div>
    <div class="sheet"></div>
    <div class="mv">…</div>       <!-- media viewer -->
    <div class="editor">…</div>   <!-- cover editor -->
  </div>

Anything appended to document.body at runtime must be appended to #frame instead. This is
the whole trick, and it is easy to get wrong later: a new overlay appended to body will
escape the column and cover the entire desktop screen.

On phones .frame carries no styles at all, so nothing changes.

=====================================================================
2. THE DESKTOP RULE
=====================================================================

  @media (min-width:760px){
    html,body{height:100%;overflow:hidden;background:#E9EAEC}
    body{display:grid;place-items:center;padding:24px}
    .frame{position:relative;width:430px;max-width:100%;
           height:min(calc(100dvh - 48px),940px);
           border-radius:36px;overflow:hidden;
           border:1px solid rgba(16,24,32,.10);
           box-shadow:0 18px 50px rgba(16,24,32,.10);
           transform:translateZ(0)}
    .app{height:100%;box-shadow:none}
    /* swipe theme */
    .pager,.screen,.cover{height:100%}
    .cover>img,.cover>iframe{height:100%}
    /* media viewer inside the column */
    .mv__z img{max-width:430px;max-height:100%}
    .mv__z video{width:430px;max-height:100%}
    .mv__z.is-turned img{max-width:100%;max-height:430px}
    .mv__z.is-turned video{width:100%;max-height:430px}
  }

  transform:translateZ(0) on .frame is not decoration. A transformed ancestor becomes the
  containing block for its position:fixed descendants, so the bottom icon row, the detail
  overlay, the backdrop, the sheets, the media viewer and the cover editor all stay inside
  the column with no per-element positioning. Remove it and every overlay spills across the
  desktop screen.

  Heights must switch from 100dvh to 100%: dvh is the viewport, not the column.

  Background #E9EAEC, flat. No gradient, no blurred hero photo behind the column — the same
  rule as everywhere else in this product.

=====================================================================
3. WHAT WE ARE NOT DOING
=====================================================================

No two-column desktop layout, no sidebar navigation, no hover-only affordances. The guest
app is a phone app; on a desktop it looks like one deliberately. If a desktop layout is
ever wanted, it is a separate project, not a set of media queries bolted onto this one.

The ADMIN is unaffected — it stays a full-width desktop application.

=====================================================================
4. VERIFY
=====================================================================

  a) 390 px wide: identical to today, pixel for pixel. This is the important one.
  b) 1440x900: a 430 px column, centred, rounded corners, flat grey around it.
  c) Open a detail page, a sheet, the share sheet, the media viewer and the cover editor —
     each stays inside the column; none covers the grey background.
  d) The bottom icon row sits at the bottom edge INSIDE the column, not at the bottom of
     the browser window.
  e) A short window (1280x700): the column shrinks with the window, nothing is cut off.
  f) 760 px exactly, and 759 px: the switch happens once, with no broken intermediate state.
```
