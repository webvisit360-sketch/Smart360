# Smart360 · vrstni red nalog za Replit

Vsaka datoteka je samostojno navodilo — prilepi vsebino bloka v Replit, priloge pa naloži
kot datoteke. Vrstni red ni naključen: kasnejše naloge se opirajo na prejšnje.

| # | Datoteka | Kaj naredi | Kaj priložiš |
|---|---|---|---|
| 1 | `logotip-v-app.md` | vstavi logotip Smart360 v glavo, na naslovnico in med ikone | `smart360-logo.zip` |
| 2 | `spodnja-vrstica-poteg.md` | spodnja vrstica s petimi ikonami + barve ikon v administraciji | `smart360-ui-paket.zip` |
| 3 | `enotne-podstrani.md` | vse prve podstrani dobijo enak videz — povsod foto-ploščice | — |
| 4 | `fotografije.md` | vnos 64 originalnih fotografij in pripis postavkam | `fotografije.zip` |
| ✓ | `popravek-predogled.md` | predogled v novem zavihku — **narejeno** | — |

## Kako preveri, da je prav

Referenca je `smart360-poteg.html` (tema poteg) oziroma `smart360-melipu-sredozemsko.html`
(sredozemska tema). Odpri referenco in Replitovo stran eno ob drugi pri širini 390 px.
Če se karkoli razlikuje — razmik, velikost pisave, barva, oblika gumba, radij, položaj
ikone — je narobe Replitova stran, ne referenca.

V `smart360-ui-paket.zip` sta `tema-poteg.css` in `zasloni-poteg.html`: to je **končan
dizajn v obliki kode**, ne opis. Agent naj razrede in vrednosti prepiše, ne izumlja svojih.

## Tri pravila, ki se najpogosteje prekršijo

1. **Nobene knjižnice komponent** (shadcn, MUI, Chakra, Bootstrap, DaisyUI) in nobenih
   ikonskih knjižnic. Ikone samo iz priloženega sprite-a.
2. **Brez prelivov, zameglitev in prosojnosti.** Čiste polne barve, ostri rezi.
3. **Fotografija je vedno nad besedilom**, prva fotografija postavke je hkrati njena ploščica.

## Kar ostaja odprto pri Replitu

- preizkus prijave s ključem (passkey) na resnični napravi
- kontrolni seznam za produkcijsko domeno
- preklop `RP_ID` / `RP_ORIGIN` na `admin.smart360.info` in nova prijava ključa
- gumb »← Administracija« v predogledu prekriva naslov zaslona — premakni ga v spodnji
  levi kot nad vrstico z ikonami, ali pa v načinu predogleda dodaj zgornji odmik
