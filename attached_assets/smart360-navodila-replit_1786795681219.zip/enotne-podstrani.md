# Vse prve podstrani enak videz — foto-ploščice povsod

Trenutno sta »Vaša nastanitev« in »Storitve v bližini« izpisani kot seznam vrstic,
»Naša ponudba« in »Odkrij okolico« pa kot mreža foto-ploščic. Poenoti na ploščice.
Zraven je popravek napake, zaradi katere napisi na ploščicah niso vidni.

---

## Navodilo za Replit (prilepi v celoti)

```
1. ONE LAYOUT FOR ALL FIRST-LEVEL SECTION SCREENS

Every section screen in the "swipe" theme must render its items as the SAME photo tile grid —
same shape, same size, same spacing. Remove the list variant entirely. There is no per-section
switch, no "useList" flag, no conditional.

Wrong (delete this):
  const useList = (k==="stay" || k==="services");
  const body = useList ? renderList(...) : renderGrid(...);

Right:
  const body = `<div class="grid2">${section.items.map(it => `
    <button class="gc" onclick="openDetail('${k}','${it.id}')">
      <img loading="lazy" src="${imageFor(it)}" alt="">
      <span class="ov"></span>
      <span class="ico">${icon(it.icon)}</span>
      <span class="cap">${it.label}</span>
    </button>`).join("")}</div>`;

The tile CSS is already in tema-poteg.css:
  .grid2{display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-top:22px}
  .gc{position:relative;border-radius:22px;overflow:hidden;height:150px;width:100%;display:block;background:var(--wash)}
  .gc img{width:100%;height:100%;object-fit:cover}
  .gc .ov{position:absolute;left:0;right:0;top:0;bottom:0;background:rgba(14,32,31,.42)}
  .gc .cap{position:absolute;left:13px;right:13px;bottom:11px;color:#fff;font-size:14.5px;
           font-weight:800;letter-spacing:-.015em;line-height:1.2}
  .gc .ico{position:absolute;top:11px;left:11px;width:32px;height:32px;border-radius:11px;
           background:rgba(255,255,255,.93);display:grid;place-items:center;color:var(--sea)}
  .gc .ico .ic{width:16px;height:16px;stroke-width:1.9}

Do not change the tile height, the radius or the two-column grid. Every tile on every section
screen must be identical in size — a guest swiping from one section to the next must see the
same layout, only different pictures.

2. THE CAPTION CLASS IS .cap, NOT .lb

The tile caption must use class="cap". Do NOT use class="lb" — .lb is the lightbox class and
carries display:none, so every caption silently disappears. If your current tiles have no
visible titles, this is the reason.

3. EVERY ITEM NEEDS A PHOTO

Each item in every section needs an image for its tile. Resolution order:
  item.tileImage  →  item.gallery[0]  →  section default image  →  tenant.hero
Never render an empty grey tile. In the admin panel, the tile image is the FIRST image field
of the item (the rule already in force: image above text), so the manager sets it in one place.

4. VERIFY
Open all four section screens at 390px width side by side. Tile size, corner radius, gap,
caption position and the icon badge must be pixel-identical across all four. Every tile must
show its caption.
```
