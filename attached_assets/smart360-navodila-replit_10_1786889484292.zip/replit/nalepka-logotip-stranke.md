# Nalepka in QR: znamka Smart360 ven, logotip stranke noter

Nalepko gleda gost v sobi. Njemu pomeni nekaj **stranka**, ne sistem, na katerem stran teče.
Zato gre znamka Smart360 z nalepke ven, na njeno mesto pride logotip nastanitve.

Naslov `smart360.info/meli-pu` na nalepki **ostane** — to ni znamka, ampak naslov, ki ga
gost prepiše, če mu skeniranje ne uspe.

---

## Navodilo za Replit (prilepi v celoti)

```
Remove the Smart360 wordmark from the printable label and from anything the guest sees
around the QR code. The tenant is what matters to a guest standing in the room.

=====================================================================
1. THE A6 LABEL
=====================================================================

  <img class="pc__logo" src="{tenant.logoTransparent}" alt="">   <!-- was the Smart360 wordmark -->
  <div class="pc__qr">…QR…</div>
  <div class="pc__n">{tenant.name}</div>
  <div class="pc__s">Skenirajte za vse o nastanitvi in okolici<br>
                     <i>Scan for everything about your stay</i></div>
  <div class="pc__u">{url without the scheme}</div>

  .pc__logo{width:auto;max-width:46mm;max-height:34mm;height:auto;display:block;
            margin:0 auto 5mm}

  max-width AND max-height, because tenant logos arrive in every proportion: a wide
  wordmark and a tall crest must both land inside the same space without pushing the QR
  code down the page. Never set a fixed height.

  Use the TRANSPARENT logo file. The label prints on white, so the square white avatar
  would show as a grey-edged box on some printers.

  The address line stays. It is not branding — it is what a guest types when the camera
  will not focus. Keep it small and blue as it is.

  Tenant with no logo uploaded: render no logo at all, and let the name carry the card.
  Do NOT fall back to the Smart360 wordmark here.

=====================================================================
2. THE SHARE SHEET
=====================================================================

Same rule: no Smart360 wordmark anywhere in the sheet. The QR plate, the address pill and
the rows stay exactly as they are.

=====================================================================
3. WHERE SMART360 STILL BELONGS
=====================================================================

  - the admin UI
  - the landing page at smart360.info
Nowhere in the guest app, on the label, or in the share sheet.

=====================================================================
4. VERIFY
=====================================================================

  a) Print the label to PDF: the tenant logo is at the top, no Smart360 wordmark, the QR
     code is not pushed off the page.
  b) Try a deliberately wide logo (e.g. 1200x200) and a tall one (400x1200): both fit the
     same block and the layout below does not move.
  c) Scan the printed PDF from paper: the code resolves to smart360.info/<slug>.
  d) A tenant with no logo: the card still prints, headed by the name.
```
