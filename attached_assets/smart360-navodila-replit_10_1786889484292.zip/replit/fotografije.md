# Navodilo za Replit — vnos originalnih fotografij

Priloži mu `fotografije.zip`. V njem sta mapa `slike/` (64 fotografij) in `slike.json`
s pripisom, katera fotografija pripada kateri postavki.

---

## Navodilo za Replit (prilepi v celoti)

```
The real photographs for the Meli Pu accommodation are in the attached zip: a folder
slike/ with 64 JPEGs and a file slike.json that maps every photo to its item.

1. UPLOAD

Put every file from slike/ into object storage under media/meli-pu/, keeping the exact
filenames. Do not rename them — slike.json refers to them by name.

2. SEED FROM slike.json

slike.json has this shape:

  {
    "_naslovnica": { "hero": "hero.jpg", "logo_gostitelja": "logo.jpg" },
    "stay": {
      "welcome": { "label":"Dobrodošli", "tile":"t_welcome.jpg",
                   "gallery":["t_welcome.jpg","g_welcome_1.jpg","g_welcome_2.jpg","g_welcome_3.jpg"] },
      ...
    },
    "offer": {...}, "explore": {...}, "services": {...},
    "_velike_kartice_sredozemska": { "stay":"b_stay.jpg", ... }
  }

Write a seed script that, for the Meli Pu tenant:
  - sets tenant.hero  = hero.jpg   (the full-screen cover photo)
  - sets tenant.logo  = logo.jpg   (host avatar only — NOT the app bar, see the logo brief)
  - for every section/item key, attaches the photos as Media rows on that Item,
    in the order given in "gallery", with "tile" as position 0
  - for the mediterran theme's four big entry cards, uses _velike_kartice_sredozemska

The item keys in slike.json are the same ids the app already uses (welcome, apart, loc,
park, gate, equip, check, wifi, house, pool, sup, scooter, …). Match on the id, not on the
label — labels get translated later.

The seed must be idempotent: running it twice must not create duplicate Media rows.

3. THE FIRST IMAGE IS THE TILE IMAGE

There is no separate "tile image" field. The FIRST image of an item is what the tile on the
section screen shows, and it is also the first photo of the gallery inside the item. This is
the rule already in force in the admin panel: image field above the text, first image wins.
Resolution order when rendering a tile:
    item.media[0]  →  section default  →  tenant.hero
Never render an empty grey tile.

4. SERVING

Serve two widths from the same original and let the browser choose:
    tile / thumbnail   620px wide, quality ~65
    gallery / lightbox 1400px wide, quality ~75
Use <img loading="lazy" decoding="async"> everywhere except the cover photo, which must be
eager and preloaded (<link rel="preload" as="image">) — it is the first thing a guest sees.
WebP with a JPEG fallback is welcome; do not upscale beyond the supplied resolution.
Strip EXIF on upload but honour the orientation flag before stripping it.

5. ADMIN

In the admin panel each item's image field must allow: add, replace, reorder by dragging,
and delete. Reordering matters, because position 0 is the tile image. When the manager
uploads a photo, resize it server-side to the two widths above — do not store 4 MB phone
originals and scale them in CSS.

6. WHAT IS STILL MISSING

Three items carry a stand-in photo until the owner shoots the real one: wifi, check, ice.
Do not treat this as an error, and do not substitute a stock image — when a replacement is
uploaded through the admin panel it simply takes position 0.
```
