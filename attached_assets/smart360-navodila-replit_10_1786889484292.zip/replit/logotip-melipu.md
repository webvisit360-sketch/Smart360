# Logotip stranke (Meli Pu) — obrezan, brez ozadja

Priloga: `melipu-logo.zip`

Stari `logo.jpg` je bil pokončen (193 × 239) in nalepljen na belo. V okroglem okvirčku
gostitelja ga je `object-fit:cover` odrezal — videl se je le trup konjička, napis
`App_Meli.pu` pa nikoli. Nova datoteka je kvadratna, logotip je znotraj varnega kroga,
zato se v krogu **ne odreže nič**.

Kaj je narejeno z izvirnikom: odstranjen bel rob okoli obrisov (slika je bila zlita na
belo, zato je na temni podlagi puščala svetlo obrobo), natančno obrezano na risbo,
povečano in rahlo izostreno.

---

## Navodilo za Replit (prilepi v celoti)

```
Replace the Meli Pu property logo with the cleaned, precisely cropped files in
melipu-logo.zip. This is per-tenant artwork (accommodation logo), NOT the Smart360
wordmark — do not touch the Smart360 wordmark in the header.

=====================================================================
1. FILES
=====================================================================

  melipu-logo.png            1158x1434  transparent, trimmed exactly to the artwork
  melipu-logo-512/256/128    same, smaller
  melipu-kvadrat-1024/512/256  square canvas, transparent, artwork inside the safe circle
  melipu-ikona-1024/512/180    square canvas on WHITE, no alpha  <- use this one
  logo.png                   384x384 square on white — the tenant logo field

Store logo.png as the tenant's logo asset (the field that used to hold logo.jpg).
Keep the transparent versions in the media library so the tenant logo can later be
placed on a photo or a coloured band without a white box around it.

=====================================================================
2. WHY SQUARE
=====================================================================

Everywhere the tenant logo appears it is a circle:

  .host__av   48x48  border-radius:50%   "Tu smo za vas" block
  .tip img    28x28  border-radius:50%   "Nasvet gostitelja"

With a 193x239 portrait image, object-fit:cover crops the top and bottom away, which is
why the old code carried the hack object-position:50% 8%. Remove that hack:

  .host__av{width:48px;height:48px;border-radius:50%;object-fit:cover;
            object-position:50% 50%;background:#fff}
  .tip img{width:28px;height:28px;border-radius:50%;object-fit:cover;
           object-position:50% 50%;background:#fff;flex:none}

The square file already leaves the margin the circle needs, so cover crops nothing.
background:#fff is the safety net if a tenant ever uploads a transparent logo.

=====================================================================
3. UPLOAD RULE FOR EVERY FUTURE TENANT
=====================================================================

When a new tenant logo is uploaded in the admin, normalise it server-side, once:

  a) if the image has an alpha channel, trim to the alpha bounding box;
     otherwise trim the uniform border colour (corner-pixel flood, tolerance 12)
  b) place it centred on a SQUARE canvas, longest side = 72 % of the canvas
  c) fill the canvas white, save 384x384 PNG as the display logo
  d) keep the trimmed transparent original as the source file

Then no tenant logo can ever be clipped in a circle, whatever shape it arrives in, and
nobody has to crop anything by hand.

=====================================================================
4. VERIFY
=====================================================================

  a) Home screen, "Tu smo za vas": the whole seahorse AND the App_Meli.pu plaque are
     visible inside the circle, nothing cut off at the top or bottom.
  b) "Nasvet gostitelja" 28 px circle: same, just smaller.
  c) Put melipu-logo.png on a dark background: no light halo around the black outlines.
  d) The Smart360 wordmark in the header is unchanged and still #3B78DC in both themes.
```
