# Enak videz podstrani — foto-ploščice v obeh temah

Nikjer v aplikaciji ni več seznama besedilnih vrstic. Povsod so fotografije.
Vsaka tema ima svojo obliko, a znotraj teme so **vse sekcije enake**.

Referenca: `zasloni-poteg.html` / `tema-poteg.css` in `zasloni-sredozemska.html` /
`tema-sredozemska.css` v paketu UI.

---

## A) Tema POTEG — mreža ploščic (prilepi v celoti)

```
Every section screen in the "swipe" theme renders its items as the SAME photo tile grid —
same shape, same size, same spacing. Remove the list variant entirely. There is no per-section
switch, no "useList" flag, no conditional.

Wrong (delete this):
  const useList = (k==="stay" || k==="services");
  const body = useList ? renderList(...) : renderGrid(...);

Right:
  const body = `<div class="grid2">${section.items.map(it => `
    <button class="gc" onclick="openDetail('${k}','${it.id}')">
      <img loading="lazy" src="${imageFor(it)}" alt="">
      <span class="ov"></span>
      <span class="ico">${icon(it.icon)}</span>
      <span class="cap">${it.label}</span>
    </button>`).join("")}</div>`;

Tile CSS (already in tema-poteg.css — copy exactly):
  .grid2{display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-top:22px}
  .gc{position:relative;border-radius:22px;overflow:hidden;height:150px;width:100%;display:block;background:var(--wash)}
  .gc img{width:100%;height:100%;object-fit:cover}
  .gc .ov{position:absolute;left:0;right:0;top:0;bottom:0;background:rgba(14,32,31,.42)}
  .gc .cap{position:absolute;left:13px;right:13px;bottom:11px;color:#fff;font-size:14.5px;
           font-weight:800;letter-spacing:-.015em;line-height:1.2}
  .gc .ico{position:absolute;top:11px;left:11px;width:32px;height:32px;border-radius:11px;
           background:rgba(255,255,255,.93);display:grid;place-items:center;color:var(--sea)}
  .gc .ico .ic{width:16px;height:16px;stroke-width:1.9}

THE CAPTION CLASS IS .cap, NOT .lb — .lb is the lightbox class and carries display:none,
so every caption silently disappears. If your tiles have no visible titles, this is why.

Do not change the tile height, the radius or the two-column grid. A guest swiping from one
section to the next must see the same layout, only different pictures.
```

---

## B) Tema SREDOZEMSKA — vodoravni pasovi sličic (prilepi v celoti)

```
In the "mediterran" theme, remove every text list and every icon-only tile grid.
Both the home page and the subpages use horizontally scrolling photo thumbnails.

1. HOME PAGE — four identical rows, one per section

Delete the .list/.row block ("Vaša nastanitev") and the .svcs/.svc block ("Storitve").
Delete the two hand-picked rows ("Priljubljeno pri gostih", "Za danes") — they showed an
arbitrary subset. Replace all of it with one loop over the four sections, each rendering
ALL of its items:

  ${SEC.map(k => {
    const m = SECMETA[k];
    return `<section class="section fade">
      <h2 class="sec__title">${m.t}</h2>
      <p class="sec__sub">${m.s}</p>
      <div class="hrow">${DATA[k].items.map(it => `
        <button class="hcard" onclick="go('item','${k}','${it.id}')">
          <span class="im"><img loading="lazy" src="${imageFor(it)}" alt=""></span>
          <b>${it.label}</b><span>${hsub(it)}</span>
        </button>`).join("")}</div>
    </section>`;
  }).join("")}

  .hrow{display:flex;gap:12px;overflow-x:auto;scrollbar-width:none;margin-top:14px;padding-bottom:2px}
  .hrow::-webkit-scrollbar{display:none}
  .hcard{width:158px;flex:none;text-align:left}
  .hcard .im{display:block;border-radius:20px;overflow:hidden;height:112px;background:var(--wash)}
  .hcard img{width:100%;height:100%;object-fit:cover}
  .hcard b{display:block;font-size:14px;font-weight:800;margin-top:10px;letter-spacing:-.01em}
  .hcard>span:not(.im){display:block;font-size:12.5px;color:var(--ink-2);font-weight:600;margin-top:1px}

The rows scroll horizontally with the mouse wheel, a trackpad swipe or a finger — no arrow
buttons, no pagination dots, no "show all" link.

2. SUBPAGE — thumbnails instead of text chips

The row that moves between items of the same section is no longer text pills. It is the same
thumbnail card, smaller, with the current item ringed in blue:

  <div class="hrow hrow--nav">
    <button class="hcard is-on">
      <span class="im"><img loading="lazy" src="..." alt=""></span><b>Dobrodošli</b></button>
    ...
  </div>

  .hrow--nav{margin-top:14px;padding:4px 16px 6px;scroll-padding-left:16px}
  .hrow--nav .hcard{width:116px}
  .hrow--nav .hcard .im{height:78px;border-radius:16px;position:relative}
  .hrow--nav .hcard b{font-size:12.5px;font-weight:700;margin-top:8px;line-height:1.2}
  .hrow--nav .hcard.is-on .im{box-shadow:0 0 0 3px var(--sea)}
  .hrow--nav .hcard.is-on b{color:var(--sea);font-weight:800}
  @media (hover:hover) and (pointer:fine){
    .hrow--nav .hcard:hover .im{box-shadow:0 0 0 3px var(--sea-soft)}
    .hrow--nav .hcard.is-on:hover .im{box-shadow:0 0 0 3px var(--sea)}
  }

  The .hrow--nav gets horizontal padding, not the parent — otherwise the blue ring of the
  first thumbnail is clipped at the screen edge.

  After every navigation, pull the selected thumbnail into view:
    requestAnimationFrame(() => {
      const on = document.querySelector(".hrow--nav .hcard.is-on");
      if (on) on.scrollIntoView({inline:"center", block:"nearest"});
    });
  Without this, on a long section the guest cannot see which item is open.

3. THE SUBTITLE LINE

Under every thumbnail title there is one short line. Slovene declines by count, so a naive
`${n} priporočil` produces "1 priporočil". Use a pluraliser with four forms — 1 / 2 / 3-4 / 5+:

  function pl(n, f){
    const r = n % 100;
    const i = (r===1) ? 0 : (r===2) ? 1 : (r===3||r===4) ? 2 : 3;
    return n + " " + f[i];
  }
  poi     → pl(n,["priporočilo","priporočili","priporočila","priporočil"]) + " v bližini"
  routes  → pl(n,["pot","poti","poti","poti"])
  events  → pl(n,["kraj","kraja","kraji","krajev"]) + " z dogodki"
  items   → pl(n,["apartma","apartmaja","apartmaji","apartmajev"])
  products→ price + " " + unit   (e.g. "25 € / dan")
  rules   → "Pravila in navodila"
  otherwise → "Informacije"

  The same line is used under the thumbnail AND in the subpage header, so it is written once.
  When translations are added, every language needs its own plural forms — do not reuse the
  Slovene function for English.

4. WHICH PHOTO

The tile / thumbnail photo is the FIRST image of the item (position 0). Same rule as in the
swipe theme. Resolution order: item.media[0] → section default → tenant.hero.
Never render an empty grey card.
```

---

## Kako preveriš

Pri širini 390 px postavi `predogled-sredozemska.html` in svojo stran eno ob drugo.
Na domači strani morajo biti **štirje enaki pasovi**, na podstrani pa pas sličic z modrim
obročem okoli odprte postavke. Če vidiš kjerkoli vrstico z ikono in puščico namesto
fotografije, je narobe.
