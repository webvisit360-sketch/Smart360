# QR koda in deljenje — tri mesta, trije nameni

Referenca: paket UI 14, gumb za deljenje na naslovnici teme poteg oziroma v glavi
sredozemske teme.

QR koda je potrebna na treh mestih, ker jo potrebujejo trije ljudje iz treh razlogov:

| Kdo | Kje | Zakaj |
|---|---|---|
| **Gost** | gumb za deljenje v aplikaciji | pošlje povezavo prijatelju, pokaže kodo sopotniku |
| **Stranka** (lastnik nastanitve) | ista aplikacija, »Natisni nalepko« | natisne kartico za v apartma **brez dostopa do administracije** |
| **Ti** | administracija, nastavitve nastanitve | prenos PNG in PDF ob predaji nove stranke |

Tretja točka je že narejena. Prvi dve sta nova naloga.

---

## Navodilo za Replit (prilepi v celoti)

```
Add sharing and a printable QR label to the guest app. The accommodation owner has no admin
account, so they must be able to print their own label from the public page.

=====================================================================
1. SHARE BUTTON
=====================================================================

Swipe theme: a third round button on the cover, between search and the language globe.
Mediterran theme: a button in the app bar, left of the language globe.
Icon #i-share (from the sprite — no icon library).

It opens the standard bottom sheet with the heading "Deli to stran":

  - a QR code of THIS accommodation's public URL, 190 px, centred in a bordered box,
    with the address printed underneath in plain text
  - "Deli" — only when navigator.share exists; calls
      navigator.share({title: tenant.name, text: tenant.subtitle, url: pageUrl})
    Wrap it in .catch(() => {}) — a cancelled share rejects and must not surface an error.
  - "Kopiraj povezavo" — writes the URL to the clipboard and changes its own label to
    "Kopirano ✓" for 1.5 s. Do not open a toast.
  - "Natisni nalepko"

=====================================================================
2. THE QR CODE ITSELF
=====================================================================

Generate the QR SERVER-SIDE as an inline SVG and send it with the page. Do not add a
client-side QR library — it is 20–50 KB of JavaScript for something that never changes.

  - error correction level M
  - quiet zone (border) 2 modules — without it many scanners fail
  - dark #14201F, no light fill (transparent), so it works on white and on the card
  - the SVG must carry a viewBox and NO fixed width/height, otherwise it renders at its
    native module size (about 33 px) instead of filling its box
  - add shape-rendering:crispEdges, otherwise the modules blur at small sizes

  Encode the canonical public URL of the tenant, always absolute and always https.
  When the slug changes, the QR changes with it — but old printed codes keep working
  through the TenantAlias 301 redirect.

=====================================================================
3. PRINTABLE LABEL — A6
=====================================================================

"Natisni nalepko" builds a hidden element and calls window.print(). Everything else on the
page is hidden by the print stylesheet, so the guest never sees a separate page:

  @media print{
    @page{size:A6;margin:8mm}
    html,body{height:auto !important;overflow:visible !important;background:#fff !important}
    body>*{display:none !important}
    #printcard{display:block !important}
  }

  The swipe theme sets html,body{height:100%;overflow:hidden} — without the override above
  the print output is one blank page.

  The card contains, in this order, centred:
    Smart360 wordmark (blue, 38 mm)
    QR code (62 mm)
    accommodation name (16 pt, 800)
    "Skenirajte za vse o nastanitvi in okolici" + the same line in English, italic, grey
    the address in blue (9 pt)

  Slovene and English together, because the person scanning may be either.

=====================================================================
4. ADMIN — ALREADY BUILT, ONE ADDITION
=====================================================================

The tenant settings screen already offers a QR PNG download. Add next to it a
"Nalepka (PDF, A6)" download that produces the same card as above, ready to hand over to a
new client. Same layout, same wording — one source, two outputs.

=====================================================================
5. VERIFY
=====================================================================

  a) Scan the QR from the sheet with a phone — it must open that accommodation, not the
     landing page.
  b) Change the slug, print again — the new code works and the old printed one still
     redirects.
  c) Print to PDF from an iPhone and from a desktop browser: one A6 page, nothing else on it,
     white background, QR sharp.
  d) On a browser without navigator.share the "Deli" row is absent, not disabled.
```

---

## Kje bi jo jaz fizično položil

- **V apartmaju:** kartica A6 na hladilniku ali na mizi ob prihodu — tam, kjer gost prvič sede.
- **Pri vhodu:** manjša nalepka ob ključavnici ali na vratih; gost, ki pride ponoči in ne najde
  navodil, tam najde vse.
- **V potrditvenem e-sporočilu:** ista koda in povezava, da ima gost aplikacijo že pred prihodom.
- **Na oglasu ali vizitki stranke:** koda deluje kot mini spletna stran nastanitve.
