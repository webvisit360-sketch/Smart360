# Smart360 · UI paket — OBVEZNO ZA UPORABO

Ta mapa je **končan dizajn**, ne predlog. Aplikacija mora izgledati točno tako.
Vsebuje **dve temi**, med katerima se izbira **v administraciji za vsako nastanitev posebej**.

## Datoteke

| Datoteka | Kaj je |
|---|---|
| `tema-sredozemska.css` | celoten slog teme **sredozemska** (navpično drsenje, spodnja navigacija) |
| `tema-poteg.css` | celoten slog teme **poteg** (vodoravni zasloni, brez spodnje navigacije) |
| `zasloni-sredozemska.html` | točna oznaka za domačo stran, podstrani in spodnjo ploščo |
| `zasloni-poteg.html` | točna oznaka za naslovnico, spodnjo vrstico, sekcijske zaslone, podrobnosti in urejevalnik |
| `urejevalnik-naslovnice.md` | polja, meje, privzete vrednosti in prenos na CSS spremenljivke |
| `ikone-sprite.svg` | vse ikone — vstavi na začetek `<body>`, uporabljaj `<use href="#i-…">` |
| `predogled-sredozemska.html` | delujoč predogled teme |
| `predogled-poteg.html` | delujoč predogled teme (vključno z urejevalnikom naslovnice) |

Odpri predogleda v brskalniku pri širini 390 px — to je videz, ki ga je treba doseči.

## Izbira teme

Polje `Tenant.theme` z vrednostma `mediterran` in `swipe`. Naloži se **samo ena** datoteka CSS, glede na temo. V administraciji je to izbirnik z dvema možnostma in kratkim opisom.

## Pravila, ki jih ni dovoljeno kršiti (za obe temi)

1. **Ne piši novega CSS.** Uporabi razrede iz priloženih datotek. Če komponenta manjka, jo sestavi iz obstoječih razredov.
2. **Ne uporabljaj knjižnice komponent** (shadcn, MUI, Chakra, Bootstrap, DaisyUI). Nobene.
3. **Ne uporabljaj Tailwind pomožnih razredov za videz.** Če je Tailwind v projektu, samo za postavitev.
4. **Barve so točno določene:** akcent `#3B78DC`, spodnji rob gumbov `#2E60B0`, besedilo `#14201F`, sekundarno `#6B7876`, črte `#E8E4DD`, topla podlaga `#F6F1E9`, opečnata `#C4552E`. Nič pastelnih krogov, nič vijolične, roza, zelene ali oranžne.
5. **Brez prelivov** (`linear-gradient`). Čisti rezi, polne barve.
6. **Ikone samo obris**, debelina 1.8, iz priloženega sprite-a. Ne emojiji, ne ikonska knjižnica, ne barvni krogi okoli ikon.
7. **Pisava:** Figtree, naslovi 800, negativen `letter-spacing` kot v CSS.
8. **Nobenih zloženk (accordion).** Kategorija je svoja stran.
9. **Nobenih besedil o stanju izdelave** v vmesniku.
10. **Prehod miške (hover):** beli in obrobljeni gumbi se obarvajo polno modro z belim besedilom, ob izhodu miške nazaj v belo; vrstice in iskalnik dobijo mehko modro `#EAF1FC`; modri gumbi potemnijo. Vse je v CSS pod `@media (hover:hover) and (pointer:fine)` — **ne odstranjuj tega pogoja**.
11. **Vsa vsebina na podstraneh je v okvirju `.card`** — tudi navadno besedilo, pravila, WiFi in zavihki. Vzorec: `.card` → neobvezna fotografija (`.card__ph` ali `.gal`) → `.card__body`.
12. **Fotografija je vedno nad besedilom**, nikoli pod ali ob njem.
13. **Gumbi imajo 3D podstavo** — `box-shadow: 0 4px 0 <temnejša>`, ob dotiku `translateY(4px)`.

## Tema SREDOZEMSKA — struktura

`appbar` (logotip Smart360) → `hero` (radij 28, višina 290, bela pilula »360°«, srček, namig)
→ `tcard` (bela kartica, ki se s –26 px prekriva čez fotografijo; naslov, podnaslov, vrstica
z oceno, peščeno iskalno polje) → »Kaj vas zanima?« s štirimi velikimi foto-karticami
(`.big`/`.bc`) → vrstica hitrih bližnjic (`.qk`) → **štirje enaki vodoravni pasovi sličic**
→ kartica gostitelja → `tabbar`.

**Nobenih seznamov in nobenih ikonskih ploščic na domači strani.** Vse štiri sekcije
(Vaša nastanitev, Naša ponudba, Odkrij okolico, Storitve v bližini) so izpisane na
popolnoma enak način: `.hrow` z vodoravnim drsenjem, v njej `.hcard` za vsako postavko —
fotografija (`.im`), pod njo naslov (`<b>`), pod njim kratka vrstica (`hsub()`).
Vsak pas ima naslov sekcije in podnaslov iz `SECMETA`. Razreda `.list`/`.row` in `.svcs`/`.svc`
se na domači strani **ne uporabljata več**.

Podstran: `navbar` → `lead` → **`.hrow.hrow--nav`** → kartice.
Med postavkami iste sekcije se premika z vodoravnim pasom sličic, ne z besedilnimi čipi.
Izbrana sličica ima modri obroč (`box-shadow:0 0 0 3px var(--sea)`) in modri napis, ob prehodu
pa se sama potegne na sredino vidnega polja (`scrollIntoView({inline:"center"})`).

## Tema POTEG — struktura

- `.app` → `.pager` (vodoravni `scroll-snap`, `scroll-snap-stop: always`) → zaporedje `.screen`, vsak `100%` širine in `100dvh` višine
- **Prvi `.screen` je naslovnica:** `.cover` s fotografijo ali `<iframe>` 3DVista čez cel zaslon, enakomeren temen film `.cover__veil`, zgoraj logotip in okrogli gumbi, spodaj `.cover__txt` z naslovom, podnaslovom in vrstico z oceno, pod njim namig »Povlecite levo«
- Sledijo sekcijski zasloni (`.sc`): števec, velik naslov, podnaslov, nato **vedno** mreža
  foto-ploščic (`.grid2`/`.gc`). **Vse prve podstrani imajo enak videz** — nikjer ni seznama,
  tudi WiFi, Hišni red in Storitve so ploščice iste oblike in velikosti.
  Ploščica: `<img>` → `.ov` (enakomerna zatemnitev) → `.ico` (znak) → `.cap` (napis).
  Napis je `.cap`, **ne** `.lb` — `.lb` je razred svetlobne škatle in ima `display:none`,
  zato napisi ob tej napaki izginejo.
- Zadnji zaslon je kontakt
- **Spodnja vrstica** (`.tabdock`) ima **pet ikon** — po eno za vsako glavno kategorijo
  (Vaša nastanitev, Naša ponudba, Odkrij okolico, Storitve v bližini, Tu smo za vas).
  Ikone so **27 px** (velike, berljive brez očal), iz istega sprite-a kot kategorije:
  `#i-home`, `#i-bag`, `#i-compass`, `#i-cart`, `#i-chat`. **Brez napisov.**
  **Aktivna ikona se samo obarva** — nobene pilule, nobenega napisa.
  Kje je gost, pove velik naslov na vrhu zaslona.
  Vrstica je **vedno fiksna in vedno prisotna** — na naslovnici, na podstraneh in tudi
  na podpodstraneh (overlay `#detail`). Zato ima `.tabdock` `z-index:105`, `.detail` pa `100`.
  V podrobnostih ostane označena ikona kategorije, iz katere je gost prišel; klik na katero
  koli ikono zapre podrobnosti in odpre tisti zaslon.
  Vrstica ima **dve stanji**:
  - **na podstraneh**: fiksen **bel pas** čez celo širino, prisloněn na spodnji rob,
    minimalne višine (58 px + varno območje), z lasnico `1px solid #E8E4DD` na vrhu.
    Vsebina se drsi **pod** njim — fotografije nikoli ne prekrijejo ikon.
    Zato imata `.sc` in `.contact` spodnji odmik `78px` oz. `86px` + varno območje.
  - **na naslovnici** (razred `on-dark`): pas **izgine**, ostanejo same bele ikone na fotografiji.
    Geometrija je **nespremenjena** — ista širina, višina in odmik od roba — spremeni se samo
    podlaga. Ikone se ob prehodu z naslovnice na prvo podstran ne smejo premakniti niti za piko.
  Barve so spremenljivke `--nv` (podstrani), `--nv-on` (izbrana), `--nv-cover` (naslovnica) —
  vse tri se nastavljajo v administraciji, glej `urejevalnik-naslovnice.md`.
- **Nobenih pikic in nobenega namiga »Povlecite levo«**
- **Nobenih puščic levo/desno** — premikanje s potegom, s klikom na ikone in s tipkovnico
- **Podrobnosti** so `#detail` overlay pod spodnjo vrstico (`.dscreen` ima spodnji odmik
  `80px` + varno območje), ki se prismuka z desne in ima **svoj vodoravni pager** (`.dpager`/`.dscreen`): s potegom se premikaš med kategorijami iste sekcije, zgoraj so čipi za neposreden skok. Vsebina se polni sproti (trenutni zaslon in soseda), ne vsa naenkrat.
- Stara spodnja navigacija `.tabbar` je v tej temi ugasnjena (`display:none`) — nadomesti jo `.tabdock`

## Urejevalnik naslovnice

Glej `urejevalnik-naslovnice.md`. Deluje v obeh temah — v sredozemski nastavlja naslov v `tcard`, v temi poteg naslov na naslovnici.

## Kako preveriš, da je prav

Postavi ustrezen predogled in svojo stran eno ob drugo pri 390 px. Če se karkoli razlikuje — razmik, velikost pisave, barva, oblika gumba, radij — je narobe tvoja stran, ne referenca.
