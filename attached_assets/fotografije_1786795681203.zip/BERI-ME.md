# Fotografije — Apartmaji Meli Pu

Vsebina te mape:

| | |
|---|---|
| `slike/` | 64 fotografij, pripravljenih za splet (JPEG, dolgi rob do 1400 px) |
| `slike.json` | pripis: katera fotografija pripada kateri postavki |

Imena povedo, kaj je kaj:

- `hero.jpg` — naslovnica (fotografija čez cel zaslon)
- `logo.jpg` — znak gostitelja (morski konjiček App_Meli.pu)
- `t_*.jpg` — **ploščica** posamezne postavke (`t` kot *tile*)
- `g_*.jpg` — **galerija** znotraj postavke (`g_apart_1`, `g_apart_2` …)
- `b_*.jpg` — velike vstopne kartice, samo za sredozemsko temo

`slike.json` je razdeljen po sekcijah (`stay`, `offer`, `explore`, `services`);
pri vsaki postavki sta `tile` in `gallery`.

## Kaj je še odprto

Tri postavke še nimajo svoje prave fotografije in imajo zaenkrat najbližjo smiselno:

| Postavka | Kaj je zdaj | Kaj bi bilo prav |
|---|---|---|
| WiFi | dnevna soba | usmerjevalnik ali nalepka z geslom |
| Prijava / Odjava | prostor z uro | vhod / sprejemni pult |
| Sladoled 24/7 | marina Izola | sam avtomat oziroma lokal |

Ko bodo te tri poslikane, se zamenja samo `t_wifi.jpg`, `t_check.jpg` in `t_ice.jpg` —
nič drugega se ne spremeni.
